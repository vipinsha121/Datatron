import Industries from './Industries';
import IndustryHeader from './IndustryHeader';
import CaseStudy from './CaseStudy';

export {
  Industries,
  IndustryHeader,
  CaseStudy,
};
