import CardImage from './CardImage';

export { CardImage };
