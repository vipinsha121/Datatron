import React, { useEffect } from "react";
import { IndustryHeader } from "../../components/reusable/Solutions";
import { RequestDemo } from "../../components/reusable/RequestDemo";
import WebinarImg from "../../assets/images/webinarimg.png";
import WebinarImg1 from "../../assets/images/webinarimg1.png";
import vector from "../../assets/images/Vector.png";
import PastEventImg from "../../assets/images/pastevent1.png";
import PastEventImg1 from "../../assets/images/strata.png";
import PastEventImg2 from "../../assets/images/pastevent2.png";
import PastEventImg3 from "../../assets/images/pastevent3.png";
import "./WebinarEvent.scss";


const WebinarEvent = () => {
    useEffect(() => {
        // scroll.scrollToTop();
        window.scrollTo(0, 0);
    }, []);

    return (
        <div className="resources-wrapper">
            <div></div>
            <IndustryHeader
                headerName="RESOURCES"
                type="Webinar & Event"
                description="Join with Datatrone experts to explore our product, features and more"
            />
            <div className="dt_resources-container">
                <div class="webinar_btn">
                    <button class="active">Webinars</button>
                    <button class="active">Events</button>
                </div>
                <div className="stay_turned">
                    <p >Stay tuned for New Webinars</p>
                    <p id="notified">Get notified for new upcoming webinars</p>
                </div>


                <div class="row">
                    <div class="col-sm-4 offset-sm-4">
                        <div class="input-group mb-3 email_address">
                            <input type="text" class="form-control" placeholder="Email Address" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                            <div class="input-group-append">
                                <button class="keep_btn btn btn-success" type="button">Keep me updated</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12 slidingImageDiv">
                            <div class="containerDiv">
                                <img src={vector} width="100%" />
                                <img src={vector} width="100%" />
                            </div>


                        </div>
                    </div>
                </div>
                <div className="webinar_div">
                    <div className="past_webinar mb-5">Past Webinars</div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={WebinarImg1} width="100%" />
                                    <div class="card-title">Long-Term ML Models in Production</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={WebinarImg} width="100%" />
                                    <div class="card-title">Talk at ODSC West 2018</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={WebinarImg1} width="100%" />
                                    <div class="card-title">Talk at Finovate Spring 2018</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="event_div">
                    <div className="past_event mb-5">Past Events</div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={PastEventImg} width="100%" />
                                    <div class="card-title">Long-Term ML Models in Production</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={PastEventImg1} width="100%" />
                                    <div class="card-title">Talk at ODSC West 2018</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={PastEventImg2} width="100%" />
                                    <div class="card-title">Talk at Finovate Spring 2018</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                            <div class="col-md-6 mb-5">
                                <div class="featured-card__component">
                                    <img src={PastEventImg3} width="100%" />
                                    <div class="card-title">Talk at Finovate Spring 2018</div>
                                    <div class="card-desc">By Harish Doddi, Co-Founer &amp; CEO
                                <p>A look at the landscape of tools for building and deploying robust, production-ready machine learning models.</p>
                                    </div>
                                    <a href="" class="btn btn-success">Watch</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <RequestDemo />
            </div>

        </div>
    );
};

export default WebinarEvent;
