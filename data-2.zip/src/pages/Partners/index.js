export { default } from './Partners';
