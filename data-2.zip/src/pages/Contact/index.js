import Contact from './Contact';

export { Contact };
