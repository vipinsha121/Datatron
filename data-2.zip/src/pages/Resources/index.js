import TermsService from './TermsService';
import PrivacyPolicy from './PrivacyPolicy';


export {
  TermsService,
  PrivacyPolicy,

};
