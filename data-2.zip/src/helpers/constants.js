const menuItems = {
  platform: {
    name: "Platform",
    submenu: [
      {
        route: "hiw",
        title: "How It Works"
      },
      {
        route: "catalog",
        title: "Model Catalog"
      },
      {
        route: "deployment",
        title: "Model Deployment"
      },
      {
        route: "model-governance",
        title: "Model Governance"
      },
      {
        route: "model-management",
        title: "Model Management"
      },
      {
        route: "monitoring",
        title: "Model Monitoring"
      },
      {
        route: "workflow",
        title: "Model Workflow"
      },
      {
        route: "overview",
        title: "Overview"
      }
    ]
  },
  solution: {
    name: "Solutions",
    submenu: [
      {
        route: "industry",
        title: "Industries"
      },
      {
        route: "usecase",
        title: "Use Cases"
      }
    ]
  },
  company: {
    name: 'Company',
    submenu: [{
      route: 'about',
      title: 'About',
    },
    {
      route: 'career',
      title: 'Careers',
    },
    {
      route: 'contact',
      title: 'Contact Us',
    },
    {
      route: 'press',
      title: 'Press',
    }],
    name: "Company",
    submenu: [
      {
        route: "about",
        title: "About Us"
      },
      {
        route: "testimonial",
        title: "Testimonial"
      },
      {
        route: "career",
        title: "Careers"
      },
      {
        route: "contact",
        title: "Contact Us"
      },
      {
        route: "press",
        title: "Press"
      }
    ]
  },
  resource: {
    name: "Resources",
    submenu: [
      {
        route: "blog",
        title: "Blog"
      },
      {
        route: "",
        title: "White Papers"
      },
      {
        route: "terms",
        title: "Terms of Service"
      },
      {
        route: "privacy-policy",
        title: "Privacy Policy"
      }
    ]
  }
};

export { menuItems };
